let d = Date(Date.now());
a = d.toString()
b = a.substr(0,15)
c = b.fontsize(8);
document.write(c)